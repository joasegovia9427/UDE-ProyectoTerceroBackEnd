package persistencia.baseDeDatos;

public class dummy {

	public dummy() {
		// TODO Auto-generated constructor stub
	}

}
