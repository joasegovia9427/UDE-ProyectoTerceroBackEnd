package persistencia.baseDeDatos.poolDeConexiones;

public interface IConexion {

}
