package persistencia;

public class dummy {

	public dummy() {
		// TODO Auto-generated constructor stub
	}

}
