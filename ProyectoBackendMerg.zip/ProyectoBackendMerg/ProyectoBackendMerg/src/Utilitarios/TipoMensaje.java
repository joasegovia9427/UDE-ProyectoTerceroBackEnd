package Utilitarios;

public enum TipoMensaje {
	INFO, SUCCESS, ERROR, WARNING;
}